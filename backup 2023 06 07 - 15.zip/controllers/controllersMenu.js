const dbConection=require('../config/database');

const menu_completo=(req,res)=>{
    dbConection.query('SELECT * FROM tabla_menu',(error,data)=>{
        if(error){
            res.status(500).json({mensaje:"problemas en la peticion del servidor"})
        }else{
            res.send(data)
            console.log("consulta realizada")
        }
    });
   
};





const traerUnaPeli=(req,res)=>{
    const tituloPeli=req.params.peli;//guardamos la info recibida desde el front en la request;

    //pedirle a la db que me traiga la info de esa peli
    dbConection.query(`SELECT * FROM peliculas WHERE titulo= ?`,[tituloPeli],(error,data)=>{
        if(error){
            res.send(error)
        }else{
            res.send(data)
        }
    });
};




const agregarUnaPeli=(req,res)=>{
    //recibir la data del front
    const{titulo,duracion,genero,tickets}=req.body;
    //pedir a la db que lo agregue
    dbConection.query('INSERT INTO peliculas (titulo,duracion,genero,tickets)VALUES(?,?,?,?)',[titulo,duracion,genero,tickets],(error,data)=>{
        if(error){
            res.send(error)
        }else{
            //res.redirect("/peliculas")//ejecuta una peticion get con lo que coloquemos adentro
            res.status(201).json({mensaje:"Pelicula cargada exitosamente"});
        }
    })
};



const eliminarPeli=(req,res)=>{
    //traer info de que peli eliminar
    const tituloPeli=req.params.peli;
    //db que la elimine
    dbConection.query('DELETE  FROM peliculas WHERE titulo=?',[tituloPeli],(error,mensajeOk)=>{
        if(error){
            res.send(error)
        }else{
            res.send("La pelicula "+ tituloPeli +" se elimino correctamente")
        }
    })

};

const eliminarPeliBody=(req,res)=>{
    const {titulo}=req.body;
    dbConection.query('DELETE  FROM peliculas WHERE titulo=?',[titulo],(error,mensajeOk)=>{
        if(error){
            res.send(error)
        }else{
            res.status(200).json("La pelicula se elimino correctamente")
        }
    })
};
module.exports={
    menu_completo,
    traerUnaPeli,
    agregarUnaPeli,
    eliminarPeli,
    eliminarPeliBody,
}