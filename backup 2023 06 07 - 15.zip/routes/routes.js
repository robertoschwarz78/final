const express= require('express');
const router=express.Router();
const {menu_completo, agregarUnaPeli} = require('../controllers/controllersMenu.js');

const {login, registrarUsuario}=require('../controllers/controllersUsuarios.js');
const {verificacionUsuario} = require('../middlewareJWT/verificacionUsuario.js');


//para logear a un usuario ya registrado
router.post('/login',login);

//registrar un usuario nuevo
router.post('/nuevoUsuario',registrarUsuario);

router.get("/menu",menu_completo)//trae todas las peliculas

router.post("/cargarPeli",verificacionUsuario,agregarUnaPeli)//agrega una pelicula


module.exports=router;

//metodos:
/*
get -> no tiene body
post
delete
put
patch
*/